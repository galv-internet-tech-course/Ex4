/**
 * Created by gal on 12/22/13.
 */

var tester = require("./tests");
tester.test();