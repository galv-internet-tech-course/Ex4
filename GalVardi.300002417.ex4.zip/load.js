/**
 * Created by gal on 12/21/13.
 */

var tester = require("./tests");
tester.load();